"""Módulo de handlers para operações de I/O."""

from .glue_handler import GlueDataHandler

__all__ = ['GlueDataHandler']
