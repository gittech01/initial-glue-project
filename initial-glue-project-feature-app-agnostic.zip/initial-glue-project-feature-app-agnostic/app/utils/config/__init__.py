"""Módulo de configurações da aplicação."""

from .settings import AppConfig

__all__ = ['AppConfig']
